#!/bin/bash

docker-compose -p level99-challenge up --build --wait --force-recreate  --renew-anon-volumes --remove-orphans