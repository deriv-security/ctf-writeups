<?php
require  '/var/www/html/includes/db.php';

function randomHexString($len) {
    return bin2hex(random_bytes($len / 2));
}

$stmt = $conn->prepare("UPDATE users SET pwd = ? WHERE username = 'admin'");
$new_pass = randomHexString(64);
$stmt->bind_param("s", $new_pass);
$stmt->execute();
$stmt->close();

?>
